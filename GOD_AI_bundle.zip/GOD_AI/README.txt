GOD AI — local browser app
==========================

Files
- index.html: app HTML, CSS, JavaScript and your supplied Liquid Glass SVG filter
- city.png: the fixed Dubai skyline background image you supplied
- secrets.js: local API key configuration

Setup
1. Open secrets.js in a text editor.
2. Replace PASTE_YOUR_OLLAMA_API_KEY_HERE with your Ollama API key. Keep the quotes.
3. Keep all four files in the same folder and open index.html in a current browser.
4. Type a message and press Enter. Shift+Enter inserts a newline.

Model / API
The app uses https://ollama.com/api/chat and model nemotron-3-nano:30b-cloud.

Security and browser compatibility
secrets.js is not secure storage: browsers download and expose its contents. The included
.gitignore helps avoid accidental commits, but static hosting cannot keep a provider key
secret. Do not publish a configured secrets.js. For a public website, use a server-side
proxy and keep the key in the server's environment. Direct browser calls can also fail if
Ollama's CORS policy blocks the page's origin; a frontend cannot bypass browser CORS.

Shortcuts
Alt+Shift+X: clear the conversation (asks for confirmation)
Alt+Shift+K: set a temporary API key for this tab (not persisted)
